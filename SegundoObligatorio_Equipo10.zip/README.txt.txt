>>>> Segundo Obligatorio Equipo 10 <<<<


---- IMPORTANTE ----
	Es necesario tener la última versión de java para ejecutar nuestro programa.


---- COMO USARLO ---- 
	Les presentamos dos maneras de ejecutar nuestro programa, la primera se encuentra en la carpeta "SegundoObligatorio_Equipo10"
	que viene en este archivo zip, ahí pueden acceder a la carpeta "dist" que contiene "SegundoObligatorio_Equipo10.jar" un archivo
	ejecutable de Java y "SegundoObligatorio_Equipo10.exe" como segunda opción.

De todas formas anexamos un ManualDeUsuario.pdf que contiene las instrucciones 	básicas para usar nuestro manejador.


---- USO ALTERNATIVO ----
	En caso de que no puedan ejecutar el programa mediante los archivos que les brindamos pueden clonar nuestro repo de GitHub:
 
	--> https://github.com/GuilleFerreira/SO_SegundaEntrega/ <--

	y ejecutarlo usando NetBeans. También anexamos un ManualDeUsuario para utilizarlo de esa manera.


Muchas gracias.
Equipo 10 - Tomás Rama, Piero Saucedo y Guillermo Ferreira.

 